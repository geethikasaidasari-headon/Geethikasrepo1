# devops-challenge

Local-first DevOps assignment repository (Windows + WSL2 + Docker Desktop + Minikube)

Contains Terraform modules, Jenkins pipeline, Kubernetes manifests, sample app, and documentation.

See `SETUP.md` for quick execution steps.
