# SETUP.md — Quick Setup Guide (Windows + WSL2 + Docker Desktop + Minikube)

Follow this file to run the full demo locally. It is a condensed one-page checklist for execution.
See Final_Report.md for detailed explanations and rationale.
