param(
  [string]$ImageTag = "1.0"
)
docker build -t localhost:5000/devops-challenge:$ImageTag -f docker/Dockerfile .
docker push localhost:5000/devops-challenge:$ImageTag
docker tag localhost:5000/devops-challenge:$ImageTag localhost:5000/devops-challenge:latest
docker push localhost:5000/devops-challenge:latest
