cd terraform
terraform init
tflint || Write-Host "tflint warnings"
tfsec . || Write-Host "tfsec warnings"
checkov -d . || Write-Host "checkov warnings"
terraform apply -auto-approve
