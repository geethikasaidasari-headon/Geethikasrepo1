Architecture summary:

- Minikube cluster (driver: Docker)
- Jenkins (Docker) builds images and deploys to Minikube
- Local registry on localhost:5000 stores images
- Terraform manages namespaces and application deployments
- Trivy + tfsec + checkov used for security scanning
